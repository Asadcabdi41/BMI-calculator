const heightInput = document.getElementById("height");
const weightInput = document.getElementById("weight");
const calculateBtn = document.getElementById("calculateBtn");
const bmiValue = document.getElementById("bmiValue");
const bmiCategory = document.getElementById("bmiCategory");
const suggestion = document.getElementById("suggestion");

calculateBtn.addEventListener('click',()=>{
    const heightCm =parseFloat(heightInput.value);
    const weight = parseFloat(weightInput.value);
    if(isNaN(heightCm) || isNaN(weight) || heightCm<=0 || weight<=0){
        Swal.fire({
            title: 'Qalad!',
            text: 'fadlan geli dherer iyo culays sax ah',
            icon: 'error',
            confirmButtonText: 'Okay'
          });
        return;
    }
    const heightM =heightCm/100;
    const bmi =(weight/(heightM+heightM)).toFixed(2)
    bmiValue.textContent=bmi;
    bmiCategory.textContent =getBMICategory(bmi);
    suggestion.textContent = getBMISuggestion(bmi);
});

function getBMICategory(bmi){
    if(bmi<18.5){
        return"UnderWeight";
    }
    else if(bmi>=18.5&&bmi<24.9){
       return"NormalWeight";
    }
    else if(bmi >= 25 && bmi < 29.9){
        return"OverWeight";
     }
     else{
        return"Obesity"
     }
 
}

function getBMISuggestion(bmi){

    if(bmi<18.5){
        return"You are underWeight consider abalanced diet with more calorie";
    }
    else if(bmi>=18.5&&bmi<24.9){
       return"Great job! you have a healthy weight keep maintaining a balanced diet";
    }
    else if(bmi >= 25 && bmi < 29.9){
        return"You are slightly OverWeight abalanced diet and regular exercise could help you ";
     }
     else{
        return" you are in the Obesity range . it is recommended to consult a healthCare provider for advice";
     }
 
}